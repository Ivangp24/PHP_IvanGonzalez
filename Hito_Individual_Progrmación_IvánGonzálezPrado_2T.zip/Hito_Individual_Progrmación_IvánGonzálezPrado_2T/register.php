<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>Registro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body style="background-color: azure">
      <nav>
      <div class="nav nav-tabs" id="nav-tab" role="tablist">
        <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true"><a href="index.php">Home</a></button>
        <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false"><a href="formulario.html">Formulario</a></button>
        <button class="nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false"><a href="mostrar.php">Publicaciones</a></button>
        <button class="nav-link" id="nav-disabled-tab" data-bs-toggle="tab" data-bs-target="#nav-disabled" type="button" role="tab" aria-controls="nav-disabled" aria-selected="false"><a href="register.php">Registro</a></button>
      </div>
      </nav>
      <div class="tab-content" id="nav-tabContent">
        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" tabindex="0">¡Bienvenidos a nuestra página sobre lenguajes de programación! Aquí encontrarás información sobre tres tipos de lenguajes: orientados a objetos, orientados a eventos y procedimentales. Te explicaremos en qué consiste cada uno y las diferencias entre ellos. ¡Explora nuestros artículos para aprender más sobre programación y mejorar tus habilidades como desarrollador!</div>
        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">¡Gracias por visitar nuestra página! Si te gustaría recibir actualizaciones sobre nuestros nuevos posts y noticias, por favor llena nuestro formulario de registro. Solo necesitas proporcionar tu nombre y correo electrónico para estar al tanto de todas nuestras novedades. ¡No te pierdas la oportunidad de estar en contacto con nosotros y ser el primero en recibir nuestros últimos artículos!</div>
        <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab" tabindex="0">¡Explora nuestro amplio catálogo de publicaciones! Aquí encontrarás una gran variedad de artículos sobre temas de interés general. Desde noticias y actualidad, hasta consejos de estilo de vida y entretenimiento, nuestra sección de publicaciones tiene algo para todos. Nuestro equipo de escritores está comprometido en brindarte contenido de calidad, informativo y entretenido. ¡Disfruta explorando nuestras publicaciones y encuentra algo que te guste!</div>
        <div class="tab-pane fade" id="nav-disabled" role="tabpanel" aria-labelledby="nav-disabled-tab" tabindex="0">¡Únete a nuestra comunidad! Regístrate en nuestra página y accede a contenido exclusivo, como descargas gratuitas y acceso anticipado a nuestras últimas publicaciones. Solo necesitas proporcionar tu nombre y correo electrónico para formar parte de nuestra comunidad de lectores. ¡No te pierdas la oportunidad de estar en contacto con nosotros y ser parte de nuestra comunidad!</div>
      </div>

      <?php
          if (isset($_POST ['email'])&&isset($_POST['contraseña'])){
          session_start();
          $token=session_id();
          echo"Sesión iniciada con id: ".$token." ";
        }
      ?>
      
      <H1 style="text-align:center; margin-top: 80px; margin-bottom: 30px;">Procede a registrarse</H1>
      <form method="post" class="form2">
        <h2 class="form-title">REGISTRO</h2>
          <div class="form-group2">
            <input type="email" name="email" placeholder="Email" class="input2">
          </div>
          <div class="form-group">
            <input type="password" name="contraseña" placeholder="Contraseña" class="input2">
          </div>
          <button type="submit" class="button2">Registrarse</button>
      </form>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>