<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>HOME</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body class="cuerpo">

    <?php setcookie('ip', $_SERVER['REMOTE_ADDR']); 
    ?>
    <?php setcookie('fecha', date('Y-m-d H:i:s')); 
    ?>
    
    <nav>
      <div class="nav nav-tabs" id="nav-tab" role="tablist">
        <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true"><a href="index.php">Home</a></button>
        <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false"><a href="formulario.html">Formulario</a></button>
        <button class="nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false"><a href="mostrar.php">Publicaciones</a></button>
        <button class="nav-link" id="nav-disabled-tab" data-bs-toggle="tab" data-bs-target="#nav-disabled" type="button" role="tab" aria-controls="nav-disabled" aria-selected="false"><a href="register.php">Registro</a></button>
      </div>
    </nav>
    <div class="tab-content" id="nav-tabContent">
      <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" tabindex="0">¡Bienvenidos a nuestra página sobre lenguajes de programación! Aquí encontrarás información sobre tres tipos de lenguajes: orientados a objetos, orientados a eventos y procedimentales. Te explicaremos en qué consiste cada uno y las diferencias entre ellos. ¡Explora nuestros artículos para aprender más sobre programación y mejorar tus habilidades como desarrollador!</div>
      <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">¡Gracias por visitar nuestra página! Si te gustaría recibir actualizaciones sobre nuestros nuevos posts y noticias, por favor llena nuestro formulario de registro. Solo necesitas proporcionar tu nombre y correo electrónico para estar al tanto de todas nuestras novedades. ¡No te pierdas la oportunidad de estar en contacto con nosotros y ser el primero en recibir nuestros últimos artículos!</div>
      <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab" tabindex="0">¡Explora nuestro amplio catálogo de publicaciones! Aquí encontrarás una gran variedad de artículos sobre temas de interés general. Desde noticias y actualidad, hasta consejos de estilo de vida y entretenimiento, nuestra sección de publicaciones tiene algo para todos. Nuestro equipo de escritores está comprometido en brindarte contenido de calidad, informativo y entretenido. ¡Disfruta explorando nuestras publicaciones y encuentra algo que te guste!</div>
      <div class="tab-pane fade" id="nav-disabled" role="tabpanel" aria-labelledby="nav-disabled-tab" tabindex="0">¡Únete a nuestra comunidad! Regístrate en nuestra página y accede a contenido exclusivo, como descargas gratuitas y acceso anticipado a nuestras últimas publicaciones. Solo necesitas proporcionar tu nombre y correo electrónico para formar parte de nuestra comunidad de lectores. ¡No te pierdas la oportunidad de estar en contacto con nosotros y ser parte de nuestra comunidad!</div>
    </div>

    <header>
        <H1 class="titulo">Diferencias entre lenguajes de programación orientada a objetos, a eventos y lenguajes procedimentales</H1> 
        <H5 class="conclusion">Los lenguajes de programación pueden ser clasificados en diferentes categorías según su paradigma de programación, es decir, la forma en que abordan la resolución de problemas y la organización del código. Entre los paradigmas más comunes se encuentran la programación orientada a objetos, la programación orientada a eventos y la programación procedimental. A continuación, se explican las diferencias entre cada uno de estos paradigmas:</H5>

            <p class="subtitulo">Programación Orientada a Objetos (POO):</p>
              
            <p>La POO es un paradigma de programación que se basa en la creación de objetos que tienen un estado y un comportamiento. Los objetos son instancias de una clase, que es una plantilla que define las propiedades y métodos que tendrán los objetos creados a partir de ella. La POO se centra en el uso de clases, objetos y la relación entre ellos, permitiendo una mayor modularidad y reutilización de código. Algunos lenguajes de programación orientada a objetos son Java, Python, C++ y Ruby.</p>

            <p class="subsubtitulo">Características de POO:</p>

            <p>Abstracción: permite modelar entidades del mundo real como objetos con características y comportamientos.</p>
            <p>Encapsulamiento: los datos y métodos que pertenecen a un objeto se mantienen protegidos y no pueden ser accedidos por otros objetos de manera directa.</p>
            <p>Herencia: permite crear nuevas clases a partir de otras ya existentes, aprovechando su funcionalidad y añadiendo nuevas características.</p>
            <p>Polimorfismo: permite que distintos objetos de la misma clase respondan de manera diferente a los mismos mensajes.</p>

            <p class="subtitulo">Programación Orientada a Eventos (POE):</p>

            <p>La POE es un paradigma de programación que se centra en la interacción entre distintos eventos que ocurren en un sistema. En lugar de ejecutar instrucciones en un orden secuencial, la POE espera a que ocurra algún evento y reacciona a él ejecutando alguna acción. La POE se utiliza comúnmente en interfaces gráficas de usuario, juegos y aplicaciones que manejan muchos eventos simultáneamente. Algunos lenguajes de programación orientada a eventos son JavaScript, C#, y Visual Basic.</p>

            <p class="subsubtitulo">Características de POE:</p>

            <p>Reactividad: los programas pueden responder a eventos de manera rápida y eficiente.</p>
            <p>Modularidad: los programas se dividen en módulos que están diseñados para responder a eventos específicos.</p>
            <p>Paralelismo: los programas pueden manejar varios eventos simultáneamente sin interrupciones.</p>

            <p class="subtitulo">Programación Procedimental:</p>

            <p>La programación procedimental es un paradigma de programación que se basa en la ejecución de instrucciones en un orden secuencial, y en la modularidad del código a través de funciones y procedimientos. En la programación procedimental, se definen una serie de funciones y procedimientos que realizan tareas específicas y se llaman desde el programa principal. Este paradigma es comúnmente utilizado en la programación de sistemas y aplicaciones de bajo nivel. Algunos lenguajes de programación procedimental son C, Pascal y Fortran.</p>

            <p class="subsubtitulo">Características de Programación Procedimental:</p>

            <p>Estructuración: los programas se dividen en procedimientos que pueden llamarse entre sí para realizar tareas complejas.</p>
            <p>Modularidad: los programas se organizan en módulos que realizan tareas específicas.</p>
            <p>Control de flujo: los programas pueden tomar decisiones y realizar iteraciones en base a condiciones lógicas.</p>

            <H5 class="conclusion">Las principales diferencias entre estos paradigmas de programación son la forma en que se organizan y estructuran los programas, y la forma en que se abordan los problemas de programación. La POO se centra en la creación de objetos y su relación, la POE en la interacción entre eventos y la programación procedimental en la ejecución secuencial de instrucciones y la modularidad a través de funciones y procedimientos. Cada uno de estos paradigmas tiene ventajas y desventajas, y la elección del paradigma dependerá del tipo de problema que se esté tratando de resolver y de las preferencias del programador.</H5>
    </header>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>